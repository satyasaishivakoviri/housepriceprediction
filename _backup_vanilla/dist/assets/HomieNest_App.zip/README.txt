The HomieNest Android App is coming soon!

This is a placeholder file for demonstration purposes.